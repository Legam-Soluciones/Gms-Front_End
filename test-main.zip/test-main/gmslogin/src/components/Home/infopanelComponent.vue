<template>
  <v-card
    height="200"
    flat
  >
    <v-snackbar
      :timeout="-1"
      :value="true"
      absolute
      color="#84D04C "
      left
      shaped
      top
    >
     Gestor para almacenar y administrar datos de muchos usuarios
    </v-snackbar>

    <v-snackbar
      :timeout="-1"
      :value="true"
      color="#007096 "
      absolute
      right
      shaped
      top
    >
      Almacena, agenda y gestionado datos de usuarios de una forma sencilla
    </v-snackbar>

    <v-snackbar
      :timeout="-1"
      :value="true"
      absolute      
      centered
      color="deep-purple accent-4"
      elevation="24"
    >
     Funciones del Gestor Administrativo - G. M .S
    </v-snackbar>

    <v-snackbar
      :timeout="-1"
      :value="true"
      absolute
      shaped  
      color="#007096"     
      left     
    >
      Exelente paltaforma para la administración de una empresa
    </v-snackbar>

    <v-snackbar
      :timeout="-1"
      :value="true"
      absolute
      shaped
      color="#84D04C"      
      right
    >
       Agenda, administra expedientes, documentos, finazas, estadistícas y tareas
    </v-snackbar>
  </v-card>
</template>