<template>
  <v-card height="150">
    <v-footer
    
      absolute
      class="font-weight-medium"
    >
      <v-col
        class="text-center"
        cols="12"
        color= "#FFFFFF"
      >
        {{ new Date().getFullYear() }} — <strong>G.M.S</strong>
      </v-col>
    </v-footer>
  </v-card>
</template>