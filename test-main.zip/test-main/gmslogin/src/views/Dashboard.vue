<template>
    <div>
        Dashboard
    </div>
</template>

<script>
export default {

    created(){
        console.log('Gestor de Más Salud Slim Clinic iniciado...')
    }
    
}
</script>